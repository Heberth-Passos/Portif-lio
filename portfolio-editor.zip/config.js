/* =========================================================
   CONFIGURAÇÃO DO PORTFÓLIO  —  edite só este arquivo
   ========================================================= */
window.PORTFOLIO = {

  // Nome que aparece no topo do site e na aba do navegador
  name: "Heberth Gomes Passos",

  // Linha pequena abaixo do nome
  tagline: "Editor de vídeo · Gaming",

  // Seus contatos (deixe como está e preencha quando quiser)
  contacts: {
    discord: "seu-id-do-discord",        // ex.: "heberth#0000" ou "heberth"
    email:   "seu-email@exemplo.com",
    twitter: "seu_usuario"               // com ou sem @, ou o link completo
  },

  // Seus 4 vídeos (aparecem em grade 2x2 nesta ordem).
  // Use "youtube" com o link ou o ID do vídeo (11 caracteres),
  // OU "file" com o caminho de um .mp4 dentro da pasta do site (ex.: "videos/montagem.mp4").
  // Se deixar vazio, aparece um cartão "Seu vídeo aqui".
  videos: [
    { title: "Título do vídeo 1", tag: "Highlights", youtube: "", file: "", poster: "" },
    { title: "Título do vídeo 2", tag: "Montage",    youtube: "", file: "", poster: "" },
    { title: "Título do vídeo 3", tag: "Trailer",    youtube: "", file: "", poster: "" },
    { title: "Título do vídeo 4", tag: "Shorts",     youtube: "", file: "", poster: "" }
  ]
};
