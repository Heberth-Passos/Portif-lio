(function () {
  "use strict";
  var C = window.PORTFOLIO || {};
  var $ = function (id) { return document.getElementById(id); };

  /* ---------- Nome, título e rodapé ---------- */
  var name = (C.name || "Seu nome").trim();
  $("nome").textContent = name;
  if (C.tagline) $("tagline").textContent = C.tagline;
  document.title = name + " · Video Editor";
  $("foot").textContent = "© " + new Date().getFullYear() + " " + name;

  /* ---------- Vídeos ---------- */
  function ytId(v) {
    if (!v) return "";
    v = String(v).trim();
    if (/^[\w-]{11}$/.test(v)) return v;
    var m = v.match(/(?:youtu\.be\/|[?&]v=|embed\/|shorts\/|live\/)([\w-]{11})/);
    return m ? m[1] : "";
  }

  function el(tag, cls, text) {
    var e = document.createElement(tag);
    if (cls) e.className = cls;
    if (text != null) e.textContent = text;
    return e;
  }

  var playSvg =
    '<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M9 6.8v10.4a.6.6 0 0 0 .9.5l8.3-5.2a.6.6 0 0 0 0-1L9.9 6.3a.6.6 0 0 0-.9.5z" fill="currentColor"/></svg>';

  function mountPlayer(box, v, id) {
    box.textContent = "";
    box.classList.add("is-playing");
    if (id) {
      var f = document.createElement("iframe");
      f.src = "https://www.youtube-nocookie.com/embed/" + id + "?autoplay=1&rel=0&modestbranding=1";
      f.title = v.title || "Vídeo";
      f.allow = "autoplay; encrypted-media; picture-in-picture; fullscreen";
      f.allowFullscreen = true;
      f.referrerPolicy = "strict-origin-when-cross-origin";
      box.appendChild(f);
    } else {
      var vid = document.createElement("video");
      vid.src = v.file;
      vid.controls = true;
      vid.autoplay = true;
      vid.playsInline = true;
      if (v.poster) vid.poster = v.poster;
      box.appendChild(vid);
    }
  }

  var grid = $("grid");
  (C.videos || []).slice(0, 4).forEach(function (v, i) {
    var id = ytId(v.youtube);
    var hasSource = !!(id || v.file);
    var card = el("article", "card");
    var box;

    if (hasSource) {
      box = el("button", "thumb");
      box.type = "button";
      box.setAttribute("aria-label", "Reproduzir: " + (v.title || "vídeo " + (i + 1)));
      var src = v.poster || (id ? "https://i.ytimg.com/vi/" + id + "/hqdefault.jpg" : "");
      if (src) {
        var img = document.createElement("img");
        img.src = src;
        img.alt = "";
        img.loading = i < 2 ? "eager" : "lazy";
        img.decoding = "async";
        box.appendChild(img);
      } else {
        box.classList.add("no-img");
      }
      var play = el("span", "play");
      play.innerHTML = playSvg;
      box.appendChild(play);
      box.addEventListener("click", function () { mountPlayer(box, v, id); }, { once: true });
    } else {
      box = el("div", "thumb empty");
      var n = el("span", "empty-n", String(i + 1).padStart(2, "0"));
      var t = el("span", "empty-t", "Seu vídeo aqui");
      box.appendChild(n);
      box.appendChild(t);
    }

    var cap = el("div", "cap");
    cap.appendChild(el("h3", "", v.title || "Vídeo " + (i + 1)));
    if (v.tag) cap.appendChild(el("span", "tag", v.tag));
    card.appendChild(box);
    card.appendChild(cap);
    grid.appendChild(card);
  });

  /* ---------- Contatos ---------- */
  var ct = C.contacts || {};
  var discord = (ct.discord || "").trim();
  var email = (ct.email || "").trim();
  var tw = (ct.twitter || "").trim();

  $("c-discord").textContent = discord;
  $("c-email").textContent = email;

  var handle = tw.replace(/^https?:\/\/(www\.)?(x|twitter)\.com\//i, "").replace(/^@/, "").replace(/[/?#].*$/, "");
  $("c-twitter").textContent = handle ? "@" + handle : "";
  $("open-twitter").href = "https://x.com/" + encodeURIComponent(handle);
  $("open-email").href = "mailto:" + email;

  var copyBtn = $("copy-discord");
  copyBtn.addEventListener("click", function () {
    var done = function () {
      copyBtn.textContent = "Copiado!";
      setTimeout(function () { copyBtn.textContent = "Copiar"; }, 1600);
    };
    if (navigator.clipboard && navigator.clipboard.writeText) {
      navigator.clipboard.writeText(discord).then(done, done);
    } else {
      var ta = document.createElement("textarea");
      ta.value = discord;
      document.body.appendChild(ta);
      ta.select();
      try { document.execCommand("copy"); } catch (e) {}
      document.body.removeChild(ta);
      done();
    }
  });
})();
